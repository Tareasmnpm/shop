<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcategories}ap_office>blockcategories_8f0ed7c57fca428f7e3f8e64d2f00918'] = 'Blok kategorii';
$_MODULE['<{blockcategories}ap_office>blockcategories_15a6f5841d9e4d7e62bec3319b4b7036'] = 'Dodaje blok zawierający kategorie produktów.';
$_MODULE['<{blockcategories}ap_office>blockcategories_23e0d4ecc25de9b2777fdaca3e2f3193'] = 'Maksymalna głębokość: Nieprawidłowa wartość.';
$_MODULE['<{blockcategories}ap_office>blockcategories_0cf328636f0d607ac24a5c435866b94b'] = 'Dynamiczny HTML: Nieprawidłowy wybór.';
$_MODULE['<{blockcategories}ap_office>blockcategories_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{blockcategories}ap_office>blockcategories_1379a6b19242372c1f23cc9adedfcdd6'] = 'Kategoria główna';
$_MODULE['<{blockcategories}ap_office>blockcategories_19561e33450d1d3dfe6af08df5710dd0'] = 'Maksymalna głębokość';
$_MODULE['<{blockcategories}ap_office>blockcategories_971fd8cc345d8bd9f92e9f7d88fdf20c'] = 'Dynamicznie';
$_MODULE['<{blockcategories}ap_office>blockcategories_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Włączony';
$_MODULE['<{blockcategories}ap_office>blockcategories_b9f5c797ebbf55adccdd8539a65a0241'] = 'Wyłączony';
$_MODULE['<{blockcategories}ap_office>blockcategories_6b46ae48421828d9973deec5fa9aa0c3'] = 'Sortuj';
$_MODULE['<{blockcategories}ap_office>blockcategories_54e4f98fb34254a6678f0795476811ed'] = 'Wg nazwy';
$_MODULE['<{blockcategories}ap_office>blockcategories_883f0bd41a4fcee55680446ce7bec0d9'] = 'Wg pozycji';
$_MODULE['<{blockcategories}ap_office>blockcategories_06f1ac65b0a6a548339a38b348e64d79'] = 'Kolejność sortowania';
$_MODULE['<{blockcategories}ap_office>blockcategories_e3cf5ac19407b1a62c6fccaff675a53b'] = 'Malejąco';
$_MODULE['<{blockcategories}ap_office>blockcategories_cf3fb1ff52ea1eed3347ac5401ee7f0c'] = 'Rosnąco';
$_MODULE['<{blockcategories}ap_office>blockcategories_5f73e737cedf8f4ccf880473a7823005'] = 'Ilość kolum stopki';
$_MODULE['<{blockcategories}ap_office>blockcategories_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{blockcategories}ap_office>blockcategories_af1b98adf7f686b84cd0b443e022b7a0'] = 'Kategorie';
$_MODULE['<{blockcategories}ap_office>blockcategories_footer_af1b98adf7f686b84cd0b443e022b7a0'] = 'Kategorie';
