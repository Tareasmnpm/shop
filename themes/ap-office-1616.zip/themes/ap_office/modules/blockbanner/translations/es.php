<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbanner}ap_office>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Bloque de Banner';
$_MODULE['<{blockbanner}ap_office>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'se ha producido un error durante el envío';
$_MODULE['<{blockbanner}ap_office>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'Parámetros actualizados';
$_MODULE['<{blockbanner}ap_office>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
$_MODULE['<{blockbanner}ap_office>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Por favor, introduzca una descripción breve pero significativa para el banner.';
$_MODULE['<{blockbanner}ap_office>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
