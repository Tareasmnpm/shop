<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpaymentlogo}ap_office>blockpaymentlogo_bbbd74a260217265015b9c8ff13b903e'] = 'منع الشعارات الدفع.';
$_MODULE['<{blockpaymentlogo}ap_office>blockpaymentlogo_3fd11fa0ede1bd0ace9b3fcdbf6a71c9'] = 'ويضيف كتلة الذي يعرض كل الشعارات الدفع الخاصة بك.';
$_MODULE['<{blockpaymentlogo}ap_office>blockpaymentlogo_b15e7271053fe9dd22d80db100179085'] = 'هذه الوحدة تحتاج إلى أن يكون مدمن مخدرات في عمود والموضوع الخاص بك لا يقوم واحد';
$_MODULE['<{blockpaymentlogo}ap_office>blockpaymentlogo_efc226b17e0532afff43be870bff0de7'] = 'تم تحديث الإعدادات.';
$_MODULE['<{blockpaymentlogo}ap_office>blockpaymentlogo_5c5e5371da7ab2c28d1af066a1a1cc0d'] = 'لا يوجد صفحة متاحة.';
$_MODULE['<{blockpaymentlogo}ap_office>blockpaymentlogo_f4f70727dc34561dfde1a3c529b6205c'] = 'الإعدادات';
$_MODULE['<{blockpaymentlogo}ap_office>blockpaymentlogo_829cb250498661a9f98a58dc670a9675'] = 'الصفحة الوجهة للارتباط كتلة و';
$_MODULE['<{blockpaymentlogo}ap_office>blockpaymentlogo_c9cc8cce247e49bae79f15173ce97354'] = 'حفظ';
$_MODULE['<{blockpaymentlogo}ap_office>blockpaymentlogo_b13fca921e8a4547cf90ca42a8b68b8a'] = 'نحن نقبل';
