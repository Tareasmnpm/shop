<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcontactinfos}ap_office>blockcontactinfos_fc02586aa99596947b184a01f43fb4ae'] = 'Контактная информация блок';
$_MODULE['<{blockcontactinfos}ap_office>blockcontactinfos_86458ae1631be34a6fcbf1a4584f5abe'] = 'Добавьте блок для добавления контактной информации';
$_MODULE['<{blockcontactinfos}ap_office>blockcontactinfos_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Конфигурация обновляется';
$_MODULE['<{blockcontactinfos}ap_office>blockcontactinfos_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{blockcontactinfos}ap_office>blockcontactinfos_c281f92b77ba329f692077d23636f5c9'] = 'Название фирмы';
$_MODULE['<{blockcontactinfos}ap_office>blockcontactinfos_dd7bf230fde8d4836917806aff6a6b27'] = 'Адрес';
$_MODULE['<{blockcontactinfos}ap_office>blockcontactinfos_1f8261d17452a959e013666c5df45e07'] = 'Номер телефона';
$_MODULE['<{blockcontactinfos}ap_office>blockcontactinfos_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-mail';
$_MODULE['<{blockcontactinfos}ap_office>blockcontactinfos_c9cc8cce247e49bae79f15173ce97354'] = 'Экономить';
$_MODULE['<{blockcontactinfos}ap_office>blockcontactinfos_02d4482d332e1aef3437cd61c9bcc624'] = 'Связаться с нами';
$_MODULE['<{blockcontactinfos}ap_office>blockcontactinfos_2e006b735fbd916d8ab26978ae6714d4'] = 'Телефон:';
$_MODULE['<{blockcontactinfos}ap_office>blockcontactinfos_6a1e265f92087bb6dd18194833fe946b'] = 'E-mail:';
$_MODULE['<{blockcontactinfos}ap_office>blockcontactinfos_9cfc9b74983d504ec71db33967591249'] = 'Свяжитесь с нами';
$_MODULE['<{blockcontactinfos}ap_office>blockcontactinfos_673ae02fffb72f0fe68a66f096a01347'] = 'Телефон:';
$_MODULE['<{blockcontactinfos}ap_office>blockcontactinfos_2bf1d5fae1c321d594fdedf05058f709'] = 'Адрес:';
