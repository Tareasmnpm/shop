<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbanner}ap_office>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Blok bannera';
$_MODULE['<{blockbanner}ap_office>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'błąd poczas wysyłania pliku';
$_MODULE['<{blockbanner}ap_office>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'Ustawienia są zaktualizowane';
$_MODULE['<{blockbanner}ap_office>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{blockbanner}ap_office>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Proszę podać krótki, ale treściwy opis banera.';
$_MODULE['<{blockbanner}ap_office>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Oszczędzać';
