<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockstore}ap_office>blockstore_68e9ecb0ab69b1121fe06177868b8ade'] = 'كتلة متجر محدد';
$_MODULE['<{blockstore}ap_office>blockstore_c1104fe0bdaceb2e1c6f77b04977b64b'] = 'يعرض ارتباط الصورة لميزة تحديد المواقع مخزن بريستاشوب ل.';
$_MODULE['<{blockstore}ap_office>blockstore_114f4c64dbac2e5c3e89a801d46db799'] = 'هذه الوحدة تحتاج إلى أن يكون مدمن مخدرات في عمود والموضوع الخاص بك لا يقوم واحد.';
$_MODULE['<{blockstore}ap_office>blockstore_7107f6f679c8d8b21ef6fce56fef4b93'] = 'صورة غير صالحة.';
$_MODULE['<{blockstore}ap_office>blockstore_df7859ac16e724c9b1fba0a364503d72'] = 'حدث خطأ أثناء محاولة تحميل الملف.';
$_MODULE['<{blockstore}ap_office>blockstore_efc226b17e0532afff43be870bff0de7'] = 'تم تحديث الإعدادات.';
$_MODULE['<{blockstore}ap_office>blockstore_f4f70727dc34561dfde1a3c529b6205c'] = 'الإعدادات';
$_MODULE['<{blockstore}ap_office>blockstore_89ca5c48bbc6b7a648a5c1996767484c'] = 'صورة كتلة';
$_MODULE['<{blockstore}ap_office>blockstore_56425383198d22fc8bb296bcca26cecf'] = 'النص كتلة';
$_MODULE['<{blockstore}ap_office>blockstore_c9cc8cce247e49bae79f15173ce97354'] = 'حفظ';
$_MODULE['<{blockstore}ap_office>blockstore_8c0caec5616160618b362bcd4427d97b'] = 'محلاتنا التجارية';
$_MODULE['<{blockstore}ap_office>blockstore_28fe12f949fd191685071517628df9b3'] = 'مشاهدة المزيد';
$_MODULE['<{blockstore}ap_office>blockstore_34c869c542dee932ef8cd96d2f91cae6'] = 'محلاتنا';
$_MODULE['<{blockstore}ap_office>blockstore_61d5070a61ce6eb6ad2a212fdf967d92'] = 'مشاهدة المزيد';
