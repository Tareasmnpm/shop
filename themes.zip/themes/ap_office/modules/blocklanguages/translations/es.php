<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklanguages}ap_office>blocklanguages_5bc2cbadb5e09b5ef9b9d1724072c4f9'] = 'Agrega un bloque que permite a los clientes seleccionar un idioma para el contenido de su tienda.';
$_MODULE['<{blocklanguages}ap_office>blocklanguages_7ba3eec2b4fa927d5294b456431a5eae'] = 'Idiomas: ';
