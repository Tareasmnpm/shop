<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcontact}ap_office>blockcontact_df8f3e2cd8d1acbb2d1aa46a45045ec5'] = 'Bloque de contactos';
$_MODULE['<{blockcontact}ap_office>blockcontact_318ed85b9852475f24127167815e85d9'] = 'Le permite agregar información adicional sobre el servicio al cliente';
$_MODULE['<{blockcontact}ap_office>blockcontact_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuración actualizada';
$_MODULE['<{blockcontact}ap_office>blockcontact_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
$_MODULE['<{blockcontact}ap_office>blockcontact_7551cf1a985728fa2798db32c2ff7887'] = 'Número de teléfono';
$_MODULE['<{blockcontact}ap_office>blockcontact_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Correo electrónico';
$_MODULE['<{blockcontact}ap_office>blockcontact_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockcontact}ap_office>blockcontact_75858d311c84e7ba706b69bea5c71d36'] = 'Nuestra línea directa está disponible 24/7';
$_MODULE['<{blockcontact}ap_office>blockcontact_673ae02fffb72f0fe68a66f096a01347'] = 'Teléfono';
$_MODULE['<{blockcontact}ap_office>blockcontact_736c5a7e834b7021bfa97180fc453115'] = 'Póngase en contacto con nuestra línea directa';
$_MODULE['<{blockcontact}ap_office>nav_02d4482d332e1aef3437cd61c9bcc624'] = 'Contacte con nosotros';
$_MODULE['<{blockcontact}ap_office>nav_320abee94a07e976991e4df0d4afb319'] = 'Llámenos ahora:';
$_MODULE['<{blockcontact}ap_office>blockcontact_9cfc9b74983d504ec71db33967591249'] = 'Contacta con nosotros';
