<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocktags}ap_office>blocktags_f2568a62d4ac8d1d5b532556379772ba'] = 'به كتلة';
$_MODULE['<{blocktags}ap_office>blocktags_b2de1a21b938fcae9955206a4ca11a12'] = 'ويضيف كتلة تحتوي على علامات المنتج الخاص بك.';
$_MODULE['<{blocktags}ap_office>blocktags_b15e7271053fe9dd22d80db100179085'] = 'هذه الوحدة تحتاج إلى أن يكون مدمن مخدرات في عمود والموضوع الخاص بك لا يقوم واحد';
$_MODULE['<{blocktags}ap_office>blocktags_8d731d453cacf8cff061df22a269b82b'] = 'يرجى إكمال الحقل \"العلامات المعروض\".';
$_MODULE['<{blocktags}ap_office>blocktags_73293a024e644165e9bf48f270af63a0'] = 'عدد غير صالح.';
$_MODULE['<{blocktags}ap_office>blocktags_c888438d14855d7d96a2724ee9c306bd'] = 'الإعدادات المحدثة';
$_MODULE['<{blocktags}ap_office>blocktags_f4f70727dc34561dfde1a3c529b6205c'] = 'الإعدادات';
$_MODULE['<{blocktags}ap_office>blocktags_726cefc6088fc537bc5b18f333357724'] = 'به عرض';
$_MODULE['<{blocktags}ap_office>blocktags_ac7203a881dd6a546c362b2e0ec180e5'] = 'تعيين عدد من العلامات التي تود أن ترى المعروضة في هذه الكتلة.';
$_MODULE['<{blocktags}ap_office>blocktags_c9cc8cce247e49bae79f15173ce97354'] = 'حفظ';
$_MODULE['<{blocktags}ap_office>blocktags_189f63f277cd73395561651753563065'] = 'الوسوم:';
$_MODULE['<{blocktags}ap_office>blocktags_49fa2426b7903b3d4c89e2c1874d9346'] = 'مشاهدة المزيد عن';
$_MODULE['<{blocktags}ap_office>blocktags_4e6307cfde762f042d0de430e82ba854'] = 'لا يوجد وسم تم تحديده بعد';
$_MODULE['<{blocktags}ap_office>blocktags_70d5e9f2bb7bcb17339709134ba3a2c6'] = 'لا يوجد وسم محدد حتى الآن';
