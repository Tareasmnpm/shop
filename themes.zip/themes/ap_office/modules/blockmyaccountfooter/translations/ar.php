<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmyaccountfooter}ap_office>blockmyaccountfooter_b97d23f7cde011d190f39468e146425e'] = 'كتلة حسابي لموقع الويب الخاص بك تذييل';
$_MODULE['<{blockmyaccountfooter}ap_office>blockmyaccountfooter_abdb95361b4c92488add0a5a37afabcb'] = 'يعرض كتلة مع ارتباطات نسبية لحسابات المستخدمين.';
$_MODULE['<{blockmyaccountfooter}ap_office>blockmyaccountfooter_ae9ec80afffec5a455fbf2361a06168a'] = 'مشاهدة الحساب الخاص بك';
$_MODULE['<{blockmyaccountfooter}ap_office>blockmyaccountfooter_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'حسابي';
$_MODULE['<{blockmyaccountfooter}ap_office>blockmyaccountfooter_74ecd9234b2a42ca13e775193f391833'] = 'سجل طلبات الشراء';
$_MODULE['<{blockmyaccountfooter}ap_office>blockmyaccountfooter_5973e925605a501b18e48280f04f0347'] = 'البضائع المستردة';
$_MODULE['<{blockmyaccountfooter}ap_office>blockmyaccountfooter_89080f0eedbd5491a93157930f1e45fc'] = 'عوائد بضاعتي';
$_MODULE['<{blockmyaccountfooter}ap_office>blockmyaccountfooter_9132bc7bac91dd4e1c453d4e96edf219'] = 'الوصلات الائتمانية';
$_MODULE['<{blockmyaccountfooter}ap_office>blockmyaccountfooter_e45be0a0d4a0b62b15694c1a631e6e62'] = 'دفتر العناوين';
$_MODULE['<{blockmyaccountfooter}ap_office>blockmyaccountfooter_b4b80a59559e84e8497f746aac634674'] = 'تحرير المعلومات الشخصية';
$_MODULE['<{blockmyaccountfooter}ap_office>blockmyaccountfooter_63b1ba91576576e6cf2da6fab7617e58'] = 'معلوماتي الشخصية';
$_MODULE['<{blockmyaccountfooter}ap_office>blockmyaccountfooter_95d2137c196c7f84df5753ed78f18332'] = 'قسائم التخفيض';
$_MODULE['<{blockmyaccountfooter}ap_office>blockmyaccountfooter_c87aacf5673fada1108c9f809d354311'] = 'تسجيل خروج';
