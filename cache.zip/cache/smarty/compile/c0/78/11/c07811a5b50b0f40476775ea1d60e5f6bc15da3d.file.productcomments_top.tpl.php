<?php /* Smarty version Smarty-3.1.19, created on 2016-08-10 18:14:49
         compiled from "C:\xampp\htdocs\shop\themes\default-bootstrap\modules\productcomments\productcomments_top.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3271757ab52f90e26e4-11424425%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c07811a5b50b0f40476775ea1d60e5f6bc15da3d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\default-bootstrap\\modules\\productcomments\\productcomments_top.tpl',
      1 => 1470839206,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3271757ab52f90e26e4-11424425',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab52f90e26e6_74377599',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab52f90e26e6_74377599')) {function content_57ab52f90e26e6_74377599($_smarty_tpl) {?><?php }} ?>
