<?php /* Smarty version Smarty-3.1.19, created on 2016-08-10 18:14:47
         compiled from "C:\xampp\htdocs\shop\themes\default-bootstrap\modules\blocklayered\blocklayered-no-products.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2502957ab52f7a4c477-90996866%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '22c1080cf271003a3dfac71ddee2a7b4d4969181' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\default-bootstrap\\modules\\blocklayered\\blocklayered-no-products.tpl',
      1 => 1470839204,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2502957ab52f7a4c477-90996866',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab52f7a4c479_24695017',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab52f7a4c479_24695017')) {function content_57ab52f7a4c479_24695017($_smarty_tpl) {?>
<div class="product_list">
	<p class="alert alert-warning"><?php echo smartyTranslate(array('s'=>'There are no products.','mod'=>'blocklayered'),$_smarty_tpl);?>
</p>
</div>
<?php }} ?>
