<?php /* Smarty version Smarty-3.1.19, created on 2016-08-10 12:22:29
         compiled from "C:\xampp\htdocs\shop\modules\leomanagewidgets\views\widgets\header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2098157ab62d5c784c6-27263696%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '60b2212dd2fbed95ca58403bcbe5d72fe90704fe' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\modules\\leomanagewidgets\\views\\widgets\\header.tpl',
      1 => 1470848912,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2098157ab62d5c784c6-27263696',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'leo_managewidget_header' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab62d5cd2262_32864189',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab62d5cd2262_32864189')) {function content_57ab62d5cd2262_32864189($_smarty_tpl) {?>

<?php if (isset($_smarty_tpl->tpl_vars['leo_managewidget_header']->value)) {?>
<script type='text/javascript'>
	<?php echo $_smarty_tpl->tpl_vars['leo_managewidget_header']->value['javascript'];?>

</script>
<?php }?><?php }} ?>
