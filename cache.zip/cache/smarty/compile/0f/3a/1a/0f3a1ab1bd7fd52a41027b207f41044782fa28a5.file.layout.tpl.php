<?php /* Smarty version Smarty-3.1.19, created on 2016-08-10 11:34:10
         compiled from "C:\xampp\htdocs\shop\admin1621ptqug\themes\default\template\controllers\login\layout.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2959357ab5782014f81-91792345%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0f3a1ab1bd7fd52a41027b207f41044782fa28a5' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\admin1621ptqug\\themes\\default\\template\\controllers\\login\\layout.tpl',
      1 => 1470839113,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2959357ab5782014f81-91792345',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'header' => 0,
    'page' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab578201cc90_64453658',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab578201cc90_64453658')) {function content_57ab578201cc90_64453658($_smarty_tpl) {?>

<?php echo $_smarty_tpl->tpl_vars['header']->value;?>

<?php echo $_smarty_tpl->tpl_vars['page']->value;?>

<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>
<?php }} ?>
