<?php /* Smarty version Smarty-3.1.19, created on 2016-08-10 11:40:56
         compiled from "C:\xampp\htdocs\shop\admin1621ptqug\themes\default\template\content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:56757ab59188a1762-18850796%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fde0451354d8871d76a21a0c80a41c34b46339f0' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\admin1621ptqug\\themes\\default\\template\\content.tpl',
      1 => 1470839110,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '56757ab59188a1762-18850796',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'content' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab59188a9466_40613064',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab59188a9466_40613064')) {function content_57ab59188a9466_40613064($_smarty_tpl) {?>
<div id="ajax_confirmation" class="alert alert-success hide"></div>

<div id="ajaxBox" style="display:none"></div>


<div class="row">
	<div class="col-lg-12">
		<?php if (isset($_smarty_tpl->tpl_vars['content']->value)) {?>
			<?php echo $_smarty_tpl->tpl_vars['content']->value;?>

		<?php }?>
	</div>
</div><?php }} ?>
