<?php /* Smarty version Smarty-3.1.19, created on 2016-08-10 13:00:11
         compiled from "C:\xampp\htdocs\shop\admin1621ptqug\themes\default\template\controllers\products\helpers\tree\tree_associated_header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:688257ab6bab54dbc9-64978894%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '42176a5dc7e9b4a7ca549f3fae15da81bdc4d7e3' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\admin1621ptqug\\themes\\default\\template\\controllers\\products\\helpers\\tree\\tree_associated_header.tpl',
      1 => 1470839115,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '688257ab6bab54dbc9-64978894',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'toolbar' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab6bab559755_80568908',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab6bab559755_80568908')) {function content_57ab6bab559755_80568908($_smarty_tpl) {?>
<div class="tree-panel-heading-controls clearfix"><?php if (isset($_smarty_tpl->tpl_vars['toolbar']->value)) {?><?php echo $_smarty_tpl->tpl_vars['toolbar']->value;?>
<?php }?></div>
<?php }} ?>
