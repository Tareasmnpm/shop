<?php /*%%SmartyHeaderCode:1815457ab62d9bc1969-92928597%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '55970a0bc8f68b5c1bc8d7b3fce0fc6ecfc4a2ce' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\ap_office\\modules\\blockcontactinfos\\blockcontactinfos.tpl',
      1 => 1470848910,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1815457ab62d9bc1969-92928597',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab7a12d09942_78851623',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab7a12d09942_78851623')) {function content_57ab7a12d09942_78851623($_smarty_tpl) {?>
<!-- MODULE Block contact infos -->
<div id="block_contact_infos" class="footer-block block">
	<div>
        <h4 class="title_block">Contáctenos</h4>
        <ul class="toggle-footer">
            <p>Etiam lorem odio, varius sit amet eleifend vitae, varius at quam. Aliquam quis metus mauris. Class aptent taciti sociosqu </p>
                             <li>
                    <i class="fa fa-phone"></i>Teléfono 
                    <p>0123-456-789</p>
                </li>
                                    	<li>
            		<i class="fa fa-map-marker"></i>Dirección: 
                    <p>My Company, 42 Puffin street
12345 Puffinville
France</p>
            	</li>
                       
                        	<li>
            		<i class="fa fa-envelope"></i>Escriba su dirección email: 
            		<span><a href="&#109;&#97;&#105;&#108;&#116;&#111;&#58;%73%61%6c%65%73@%79%6f%75%72%63%6f%6d%70%61%6e%79.%63%6f%6d" >&#x73;&#x61;&#x6c;&#x65;&#x73;&#x40;&#x79;&#x6f;&#x75;&#x72;&#x63;&#x6f;&#x6d;&#x70;&#x61;&#x6e;&#x79;&#x2e;&#x63;&#x6f;&#x6d;</a></span>
            	</li>
                    </ul>
    </div>
</div>
<!-- /MODULE Block contact infos -->
<?php }} ?>
