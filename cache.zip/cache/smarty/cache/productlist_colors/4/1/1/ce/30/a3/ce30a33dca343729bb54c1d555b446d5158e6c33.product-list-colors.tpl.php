<?php /*%%SmartyHeaderCode:3273757ab62d7c45f61-68738864%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ce30a33dca343729bb54c1d555b446d5158e6c33' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\ap_office\\product-list-colors.tpl',
      1 => 1470848911,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3273757ab62d7c45f61-68738864',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab69f9d2a420_53331904',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab69f9d2a420_53331904')) {function content_57ab69f9d2a420_53331904($_smarty_tpl) {?><ul class="color_to_pick_list clearfix">
									<li>
				<a href="http://localhost/shop/vestidos-noche/4-vestido-estampado.html#/1-size-s/7-color-beige" id="color_16" class="color_pick" style="background:#f5f5dc;">
									</a>
			</li>
											<li>
				<a href="http://localhost/shop/vestidos-noche/4-vestido-estampado.html#/1-size-s/24-color-rosa" id="color_43" class="color_pick" style="background:#FCCACD;">
									</a>
			</li>
			</ul>
<?php }} ?>
