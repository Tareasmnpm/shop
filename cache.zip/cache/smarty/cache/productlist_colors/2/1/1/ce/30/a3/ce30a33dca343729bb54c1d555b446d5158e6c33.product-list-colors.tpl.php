<?php /*%%SmartyHeaderCode:3273757ab62d7c45f61-68738864%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ce30a33dca343729bb54c1d555b446d5158e6c33' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\ap_office\\product-list-colors.tpl',
      1 => 1470848911,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3273757ab62d7c45f61-68738864',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab69f9c209f4_58129171',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab69f9c209f4_58129171')) {function content_57ab69f9c209f4_58129171($_smarty_tpl) {?><ul class="color_to_pick_list clearfix">
									<li>
				<a href="http://localhost/shop/blusas/2-blusa.html#/1-size-s/8-color-blanco" id="color_8" class="color_pick" style="background:#ffffff;">
									</a>
			</li>
											<li>
				<a href="http://localhost/shop/blusas/2-blusa.html#/1-size-s/11-color-negro" id="color_7" class="color_pick" style="background:#434A54;">
									</a>
			</li>
			</ul>
<?php }} ?>
