<?php /*%%SmartyHeaderCode:162257ab62d645e2f1-12852818%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '500ae4fdafdc5ffb266d6b170af1a4e76df17d9b' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\ap_office\\modules\\blocksocial\\blocksocial.tpl',
      1 => 1470848910,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '162257ab62d645e2f1-12852818',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab7a11e7d731_04010545',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab7a11e7d731_04010545')) {function content_57ab7a11e7d731_04010545($_smarty_tpl) {?>
<div id="social_block" class="block">
	 <div class="block_content toggle-footer">	 	
	<ul>
						<li class="facebook">
					<a target="_blank" href="http://www.facebook.com/prestashop" class="btn-tooltip" data-original-title="Facebook">
						<span>Facebook</span>
					</a>
				</li>
									<li class="twitter">
					<a target="_blank" href="http://www.twitter.com/prestashop" class="btn-tooltip" data-original-title="Twitter">
						<span>Twitter</span>
					</a>
				</li>
									<li class="rss">
					<a target="_blank" href="http://www.prestashop.com/blog/en/" class="btn-tooltip" data-original-title="RSS">
						<span>RSS</span>
					</a>
				</li>
			                	        	<li class="google-plus">
	        		<a target="_blank" href="https://www.google.com/+prestashop" class="btn-tooltip" data-original-title="Google Plus" rel="publisher">
	        			<span>Google Plus</span>
	        		</a>
	        	</li>
	                                	</ul>
	 </div>
</div>

<?php }} ?>
