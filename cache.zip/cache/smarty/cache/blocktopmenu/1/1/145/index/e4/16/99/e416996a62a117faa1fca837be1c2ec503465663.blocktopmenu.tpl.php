<?php /*%%SmartyHeaderCode:2850857ab62d706e891-43494941%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e416996a62a117faa1fca837be1c2ec503465663' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\ap_office\\modules\\blocktopmenu\\blocktopmenu.tpl',
      1 => 1470848910,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2850857ab62d706e891-43494941',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab7a126d9333_02926652',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab7a126d9333_02926652')) {function content_57ab7a126d9333_02926652($_smarty_tpl) {?>	<!-- Menu -->
	<div id="block_top_menu" class="sf-contener clearfix">
		<div class="cat-title">Menú</div>
		<ul class="sf-menu clearfix menu-content">
			<li><a href="http://localhost/shop/3-mujer" title="Mujer">Mujer</a><ul><li><a href="http://localhost/shop/4-tops" title="Tops">Tops</a><ul><li><a href="http://localhost/shop/5-camisetas" title="Camisetas">Camisetas</a></li><li><a href="http://localhost/shop/7-blusas" title="Blusas">Blusas</a></li></ul></li><li><a href="http://localhost/shop/8-vestidos" title="Vestidos">Vestidos</a><ul><li><a href="http://localhost/shop/9-vestidos-informales" title="Vestidos informales">Vestidos informales</a></li><li><a href="http://localhost/shop/10-vestidos-noche" title="Vestidos de noche">Vestidos de noche</a></li><li><a href="http://localhost/shop/11-vestidos-verano" title="Vestidos de verano">Vestidos de verano</a></li></ul></li><li class="category-thumbnail"><div><img src="http://localhost/shop/img/c/3-0_thumb.jpg" alt="Mujer" title="Mujer" class="imgm" /></div><div><img src="http://localhost/shop/img/c/3-1_thumb.jpg" alt="Mujer" title="Mujer" class="imgm" /></div></li></ul></li><li><a href="http://localhost/shop/8-vestidos" title="Vestidos">Vestidos</a><ul><li><a href="http://localhost/shop/9-vestidos-informales" title="Vestidos informales">Vestidos informales</a></li><li><a href="http://localhost/shop/10-vestidos-noche" title="Vestidos de noche">Vestidos de noche</a></li><li><a href="http://localhost/shop/11-vestidos-verano" title="Vestidos de verano">Vestidos de verano</a></li></ul></li><li><a href="http://localhost/shop/5-camisetas" title="Camisetas">Camisetas</a></li>
					</ul>
	</div>
	<!--/ Menu -->
<?php }} ?>
