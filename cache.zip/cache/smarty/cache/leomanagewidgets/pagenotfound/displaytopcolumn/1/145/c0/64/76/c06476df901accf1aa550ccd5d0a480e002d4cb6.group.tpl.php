<?php /*%%SmartyHeaderCode:625757ab62d62d3a18-58283284%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c06476df901accf1aa550ccd5d0a480e002d4cb6' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\modules\\leomanagewidgets\\views\\widgets\\group.tpl',
      1 => 1470848912,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '625757ab62d62d3a18-58283284',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab7a13028b45_42536350',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab7a13028b45_42536350')) {function content_57ab7a13028b45_42536350($_smarty_tpl) {?>
            <div class="row" 
                    >
            
                                                                                    <div class="widget col-lg-12 col-md-12 col-sm-12 col-xs-12 col-sp-12 nopadding noborder"
                            >
                                                                                                
<div class="widget-html block">
		<div class="block_content">
		<div class="ImageWrapper chrome-fix"><img class="img-responsive" src="/shop/themes/ap_office/img/modules/leomanagewidgets/top_column.png" alt="" />
<div class="ImageOverlayS"></div>
</div>
	</div>
</div>
                                                                                    </div>
                                                        </div>
    <?php }} ?>
