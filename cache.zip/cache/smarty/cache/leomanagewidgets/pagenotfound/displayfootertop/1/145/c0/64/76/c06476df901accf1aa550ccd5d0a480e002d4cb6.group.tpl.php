<?php /*%%SmartyHeaderCode:625757ab62d62d3a18-58283284%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c06476df901accf1aa550ccd5d0a480e002d4cb6' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\modules\\leomanagewidgets\\views\\widgets\\group.tpl',
      1 => 1470848912,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '625757ab62d62d3a18-58283284',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ab7a120e5c31_01585114',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ab7a120e5c31_01585114')) {function content_57ab7a120e5c31_01585114($_smarty_tpl) {?>
            <div class="row" 
                    >
            
                                                                                    <div class="widget col-lg-3 col-md-3 col-sm-4 col-xs-4 col-sp-12"
                            >
                                                                                                <div id="social_block" class="block">
	 <div class="block_content toggle-footer">	 	
	<ul>
						<li class="facebook">
					<a target="_blank" href="http://www.facebook.com/prestashop" class="btn-tooltip" data-original-title="Facebook">
						<span>Facebook</span>
					</a>
				</li>
									<li class="twitter">
					<a target="_blank" href="http://www.twitter.com/prestashop" class="btn-tooltip" data-original-title="Twitter">
						<span>Twitter</span>
					</a>
				</li>
									<li class="rss">
					<a target="_blank" href="http://www.prestashop.com/blog/en/" class="btn-tooltip" data-original-title="RSS">
						<span>RSS</span>
					</a>
				</li>
			                	        	<li class="google-plus">
	        		<a target="_blank" href="https://www.google.com/+prestashop" class="btn-tooltip" data-original-title="Google Plus" rel="publisher">
	        			<span>Google Plus</span>
	        		</a>
	        	</li>
	                                	</ul>
	 </div>
</div>

                                                                                    </div>
                                                                                <div class="widget col-lg-9 col-md-9 col-sm-8 col-xs-8 col-sp-12 custhtmlcarosel"
                            >
                                                                                                <div id="custhtmlcarosel4193" class="block custhtmlcarosel">
        	<a class="carousel-control left" href="#custhtmlcarosel4193"   data-slide="prev">&lsaquo;</a>
	<a class="carousel-control right" href="#custhtmlcarosel4193"  data-slide="next">&rsaquo;</a>
        <div class="carousel-inner">
            <div class="item item active"><div class="custom-info">
<div class="text_people">
<p>Nunc in sem quis metus commodo blandit. Etiam lorem odio, varius sit amet eleifend vitae, varius at quam. Aliquam quis metus mauris. Class aptent taciti sociosqu per inceptos himenaeos.</p>
</div>
<div class="time">
<p>08:36 am, Jun 05, 2014</p>
</div>
</div></div>
            <div class="item item "><div class="custom-info">
<div class="text_people">
<p>Class aptent taciti sociosqu ad litora torquent per conia nostra, per inceptos himenaeos. varius sit amet eleifend vitae, varius at quam. Aliquam quis metus mauris.</p>
</div>
<div class="time">
<p>08:36 am, Jun 05, 2014</p>
</div>
</div></div>
            <div class="item item "><div class="custom-info">
<div class="text_people">
<p>Nunc in sem quis metus commodo blandit. Etiam lorem odio, varius sit amet eleifend vitae, varius at quam. Aliquam quis metus mauris. Class aptent taciti sociosqu , per inceptos himenaeos.</p>
</div>
<div class="time">
<p>08:36 am, Jun 05, 2014</p>
</div>
</div></div>
            <div class="item item "><div class="custom-info">
<div class="text_people">
<p>Class aptent taciti sociosqu ad litora torquent per conia nostra, per inceptos himenaeos. Nunc in sem quis metus commodo blandit. Aliquam quis metus mauris.</p>
</div>
<div class="time">
<p>08:36 am, Jun 05, 2014</p>
</div>
</div></div>
            <div class="item item "><div class="custom-info">
<div class="text_people">
<p>Nunc in sem quis metus commodo blandit. Class aptent taciti sociosqu ad litora torquent . Etiam lorem odio, varius sit varius at quam. Aliquam quis metus mauris.</p>
</div>
<div class="time">
<p>08:36 am, Jun 05, 2014</p>
</div>
</div></div>
       
    </div>
</div>
<script type="text/javascript">

$(document).ready(function() {
    $('#custhtmlcarosel4193').each(function(){
        $(this).carousel({
            pause: true,
            interval: false
        });
    });
     
});


</script>                                                                                    </div>
                                                        </div>
    <?php }} ?>
